package com.example.demo;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {
	
	@Autowired
	UserRepository userRepo;
	
	
	@GetMapping("/login")
	public String loginPage() {
		return "login";
	}
	
	@PostMapping("registerSubmit")
	public String registerSubmit(@RequestParam("username") String username,@RequestParam("email") String email,@RequestParam("pswd") String password) {
		
		User newUser=new User();
		Role newRole=new Role();
		newRole.setRole("ROLE_USER");
		Set<Role> roles=new HashSet<Role>();
		roles.add(newRole);
		
		newUser.setName(username);
		newUser.setEmail(email);
		//BCryptPasswordEncoder passwordEncoder=new BCryptPasswordEncoder();
		//String encryptedPW=passwordEncoder.encode(password);
		newUser.setPassword(password);
		newUser.setRoles(roles);
		
		userRepo.save(newUser);
		
		return "login";
		
	}

}
